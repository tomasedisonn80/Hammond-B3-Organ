#!/usr/bin/env python3
"""A43's bounded independent first-use observation; no project modules imported."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import time

ROOT = Path('/workspace/scratch/3edffb787db3')
REPO = ROOT / 'Hammond-B3-Organ'
PRIVATE = ROOT / 'a43-first-use'
CWD = PRIVATE / 'First session Ω'
LOGS = PRIVATE / 'supported-originals'
TOOL = ROOT / 'build-native/hammond_registration'
PACK_ROOT = REPO / 'data/registrations/starter-v1'
PACK = PACK_ROOT / 'entries'
LIBRARY = CWD / 'inputs' / 'Ma bibliothèque Ω'
DESTINATION = CWD / 'outputs' / 'Auditions été'
CURRENT = CWD / 'inputs' / 'Current état.b3controls'

# Literal current bytes deliberately disagree with Warm Comp in every control
# category. Expected Warm Comp fields were transcribed from the independent
# recipes.json entry and the documented grammar, never parsed by product code.
CURRENT_BYTES = b'''B3CONTROLS4
registration_catalog atlas-chapel-nominal-v1 sha256 c9f1dd2d4287448325834f66f3998f4c32a41f84bc7ec7216e7b72ebcbf722cf
expression 0.375
percussion enabled 1 harmonic third volume soft decay fast
pedal drawbars 2 7
manual upper selected A fixed_registration C# route_enabled 0
bank A 0 1 2 3 4 5 6 7 8
bank B 8 7 6 5 4 3 2 1 0
manual lower selected A fixed_registration A route_enabled 0
bank A 1 3 5 7 0 2 4 6 8
bank B 8 6 4 2 0 7 5 3 1
end
'''
SAVED_BYTES = b'''B3CONTROLS4
registration_catalog atlas-chapel-nominal-v1 sha256 c9f1dd2d4287448325834f66f3998f4c32a41f84bc7ec7216e7b72ebcbf722cf
expression 0.625
percussion enabled 0 harmonic second volume normal decay slow
pedal drawbars 3 0
manual upper selected B fixed_registration none route_enabled 1
bank A 8 0 8 0 0 0 0 0 0
bank B 8 0 8 4 0 0 0 0 0
manual lower selected B fixed_registration none route_enabled 1
bank A 0 0 8 4 0 0 0 0 0
bank B 0 0 8 3 0 0 0 0 0
end
'''
PRESERVED_BYTES = b'''B3CONTROLS4
registration_catalog atlas-chapel-nominal-v1 sha256 c9f1dd2d4287448325834f66f3998f4c32a41f84bc7ec7216e7b72ebcbf722cf
expression 0.375
percussion enabled 0 harmonic second volume normal decay slow
pedal drawbars 3 0
manual upper selected B fixed_registration none route_enabled 1
bank A 8 0 8 0 0 0 0 0 0
bank B 8 0 8 4 0 0 0 0 0
manual lower selected B fixed_registration none route_enabled 1
bank A 0 0 8 4 0 0 0 0 0
bank B 0 0 8 3 0 0 0 0 0
end
'''

SOURCE_PATHS = [
    'tools/registration.cpp', 'tools/ControlFileInput.cpp',
    'tools/ControlFileInput.h', 'apps/standalone/RegistrationLibrary.cpp',
    'apps/standalone/RegistrationLibrary.h', 'src/ControlStateIO.cpp',
    'src/ControlState.cpp', 'src/FixedRegistration.cpp',
    'include/hammond/ControlStateIO.h', 'include/hammond/ControlState.h',
    'include/hammond/FixedRegistration.h',
]
READING_PATHS = [
    'docs/REGISTRATION_GUIDE.md', 'docs/REGISTRATION_CLI_CONTRACT.md',
    'docs/CONTROL_STATE_FORMAT.md',
    'data/registrations/starter-v1/README.md',
    'data/registrations/starter-v1/recipes.json',
]

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def file_identity(path: Path) -> dict:
    stat = path.stat()
    return {'bytes': stat.st_size, 'sha256': sha(path.read_bytes()),
            'mtime_ns': stat.st_mtime_ns, 'mode': oct(stat.st_mode & 0o777)}

def inventory(path: Path) -> dict:
    if not path.exists():
        return {'exists': False, 'directories': [], 'files': {}}
    return {'exists': True,
            'directories': sorted(p.relative_to(path).as_posix()
                                  for p in path.rglob('*') if p.is_dir()),
            'files': {p.relative_to(path).as_posix(): file_identity(p)
                      for p in sorted(path.rglob('*')) if p.is_file()}}

def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()

def write_json(path: Path, obj: object) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

CWD.mkdir(exist_ok=True)
(CWD / 'inputs').mkdir()
(CWD / 'outputs').mkdir()
LOGS.mkdir()
CURRENT.write_bytes(CURRENT_BYTES)
(LOGS / 'literal-current.b3controls').write_bytes(CURRENT_BYTES)
(LOGS / 'literal-expected-saved.b3performance').write_bytes(SAVED_BYTES)
(LOGS / 'literal-expected-current.b3performance').write_bytes(PRESERVED_BYTES)
(LOGS / 'guide-read.md').write_bytes((REPO / READING_PATHS[0]).read_bytes())

cache = (ROOT / 'build-native/CMakeCache.txt').read_text()
config_keys = ['BUILD_TESTING', 'CMAKE_BUILD_TYPE', 'CMAKE_CXX_COMPILER',
               'CMAKE_GENERATOR', 'CMAKE_HOME_DIRECTORY',
               'HAMMOND_BUILD_STANDALONE', 'HAMMOND_BUILD_VST3',
               'HAMMOND_ENABLE_MIDI']
config = {line.split(':', 1)[0]: line.split('=', 1)[1]
          for line in cache.splitlines()
          if any(line.startswith(key + ':') for key in config_keys)}
receipt = {
    'schema': 'a43-first-use-admission-v1',
    'worker': '/root/w08_a43', 'wave': 8,
    'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'repo': str(REPO), 'cwd': str(CWD), 'tool': str(TOOL),
    'scope': '14 native CLI invocations; Linux supported layout with separate ASCII inputs/outputs branches',
    'git_head_before': git('rev-parse', 'HEAD'),
    'git_tree_before': git('rev-parse', 'HEAD^{tree}'),
    'git_source_diff_before': git('diff', '--name-only', 'HEAD', '--', *SOURCE_PATHS),
    'platform': {'system': platform.platform(), 'machine': platform.machine(),
                 'python': platform.python_version(),
                 'LC_ALL': os.environ.get('LC_ALL'), 'LANG': os.environ.get('LANG')},
    'build_configuration_observed': config,
    'tool_before': file_identity(TOOL),
    'source_before': {p: file_identity(REPO / p) for p in SOURCE_PATHS},
    'read_documents': {p: file_identity(REPO / p) for p in READING_PATHS},
    'pack_before': inventory(PACK_ROOT),
    'current_before': file_identity(CURRENT),
    'independent_oracle': {
        'basis': 'Literal bytes, documented B3CONTROLS4 grammar and independent recipes.json Warm Comp values; no production parser/generator used as an oracle.',
        'current': CURRENT_BYTES.decode(),
        'expected_saved': SAVED_BYTES.decode(),
        'expected_registration_materialized': PRESERVED_BYTES.decode(),
    },
    'processes': [], 'checks': [],
}

def check(name: str, value: bool) -> None:
    receipt['checks'].append({'name': name, 'passed': bool(value)})

def invoke(name: str, args: list[str], expected_rc: int,
           expected_committed: bool) -> dict:
    number = len(receipt['processes']) + 1
    stem = f'{number:02d}-{name}'
    argv = [str(TOOL), *[str(arg) for arg in args]]
    start = time.monotonic()
    before_hash = sha(TOOL.read_bytes())
    result = subprocess.run(argv, cwd=CWD, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=15, check=False)
    elapsed = time.monotonic() - start
    (LOGS / (stem + '.stdout.json')).write_bytes(result.stdout)
    (LOGS / (stem + '.stderr.txt')).write_bytes(result.stderr)
    report = json.loads(result.stdout)
    process = {
        'number': number, 'name': name, 'cwd': str(CWD), 'argv': argv,
        'posix_shell_command': shlex.join(argv), 'returncode': result.returncode,
        'expected_returncode': expected_rc, 'elapsed_seconds': elapsed,
        'tool_sha256': before_hash,
        'stdout': {'file': stem + '.stdout.json', 'bytes': len(result.stdout),
                   'sha256': sha(result.stdout)},
        'stderr': {'file': stem + '.stderr.txt', 'bytes': len(result.stderr),
                   'sha256': sha(result.stderr)},
        'result': {key: report[key] for key in
                   ('schema', 'command', 'outcome', 'code', 'committed')},
    }
    receipt['processes'].append(process)
    check(stem + ': expected exit', result.returncode == expected_rc)
    check(stem + ': committed', report.get('committed') is expected_committed)
    check(stem + ': one JSON object and LF',
          isinstance(report, dict) and result.stdout.endswith(b'\n')
          and result.stdout.count(b'\n') == 1
          and report.get('schema') == 'hammond-registration-cli-v1')
    check(stem + ': empty stderr', result.stderr == b'')
    check(stem + ': same executable', before_hash == receipt['tool_before']['sha256'])
    write_json(PRIVATE / 'observation-supported-in-progress.json', receipt)
    print(f'{number:02d} {name}: exit {result.returncode}, '
          f'{report.get("code")}, committed={report.get("committed")}', flush=True)
    return report

help_report = invoke('help', ['--help'], 0, False)
discovery = invoke('discover-pack', ['list', '--library', PACK], 0, False)
inspect_reg = invoke('inspect-pack-registration',
                     ['inspect', '--library', PACK, '--key',
                      '02 Warm Comp.b3registration'], 0, False)
inspect_perf = invoke('inspect-pack-performance',
                      ['inspect', '--library', PACK, '--key',
                       '02 Warm Comp.b3performance'], 0, False)
missing = invoke('list-fresh-library', ['list', '--library', LIBRARY], 0, False)
check('read-only fresh list leaves library absent', not LIBRARY.exists())
check('read-only discovery leaves destination absent', not DESTINATION.exists())
check('pack discovery exactly 24 valid entries',
      len(discovery['catalog']['entries']) == 24
      and discovery['catalog']['candidate_count'] == 24
      and discovery['catalog']['warning_count'] == 0
      and discovery['catalog']['complete'] is True)
check('fresh library reports empty entries', missing['catalog']['entries'] == [])
check('registration inspect matches independent literal bytes',
      inspect_reg['entry']['canonical_controls'].encode() == SAVED_BYTES)
check('performance inspect matches independent literal bytes',
      inspect_perf['entry']['canonical_controls'].encode() == SAVED_BYTES)
check('read-only discovery preserves whole pack',
      inventory(PACK_ROOT) == receipt['pack_before'])

import_reg = invoke('import-registration',
                    ['import', '--input', PACK / '02 Warm Comp.b3registration',
                     '--library', LIBRARY, '--name', 'Warm Comp',
                     '--scope', 'registration'], 0, True)
import_perf = invoke('import-performance',
                     ['import', '--input', PACK / '02 Warm Comp.b3performance',
                      '--library', LIBRARY, '--name', 'Warm Performance',
                      '--scope', 'performance'], 0, True)
chosen = invoke('list-selected-library', ['list', '--library', LIBRARY], 0, False)
receipt['library_after_import'] = inventory(LIBRARY)
check('selected library has exact two suffixes and filenames',
      sorted(receipt['library_after_import']['files']) ==
      ['Warm Comp.b3registration', 'Warm Performance.b3performance'])
check('both imports preserve complete saved literal bytes',
      (LIBRARY / 'Warm Comp.b3registration').read_bytes() == SAVED_BYTES
      and (LIBRARY / 'Warm Performance.b3performance').read_bytes() == SAVED_BYTES)
check('selected catalog reports only two ready entries without warning',
      len(chosen['catalog']['entries']) == 2
      and chosen['catalog']['candidate_count'] == 2
      and chosen['catalog']['warning_count'] == 0)

prepared_reg = invoke('materialize-current',
                      ['materialize', '--library', LIBRARY, '--key',
                       'Warm Comp.b3registration', '--current', CURRENT,
                       '--destination', DESTINATION, '--name', 'Warm Current'],
                      0, True)
prepared_perf = invoke('materialize-saved',
                       ['materialize', '--library', LIBRARY, '--key',
                        'Warm Performance.b3performance', '--destination',
                        DESTINATION, '--name', 'Warm Saved'], 0, True)
receipt['destination_after_materialize'] = inventory(DESTINATION)
current_inspect = invoke('inspect-prepared-current',
                        ['inspect', '--library', DESTINATION, '--key',
                         'Warm Current.b3performance'], 0, False)
saved_inspect = invoke('inspect-prepared-saved',
                      ['inspect', '--library', DESTINATION, '--key',
                       'Warm Saved.b3performance'], 0, False)

repeat_import = invoke('refuse-repeated-import',
                       ['import', '--input', PACK / '02 Warm Comp.b3registration',
                        '--library', LIBRARY, '--name', 'Warm Comp',
                        '--scope', 'registration'], 3, False)
repeat_materialize = invoke('refuse-repeated-materialize',
                            ['materialize', '--library', LIBRARY, '--key',
                             'Warm Comp.b3registration', '--current', CURRENT,
                             '--destination', DESTINATION, '--name',
                             'Warm Current'], 3, False)

check('registration materialization is exact literal state with expression 0.375',
      (DESTINATION / 'Warm Current.b3performance').read_bytes() == PRESERVED_BYTES)
check('performance materialization is exact literal state with expression 0.625',
      (DESTINATION / 'Warm Saved.b3performance').read_bytes() == SAVED_BYTES)
check('current output inspection matches all literal fields',
      current_inspect['entry']['canonical_controls'].encode() == PRESERVED_BYTES)
check('saved output inspection matches all literal fields',
      saved_inspect['entry']['canonical_controls'].encode() == SAVED_BYTES)
check('registration report identifies complete supplied current state',
      prepared_reg['input']['canonical_controls'].encode() == CURRENT_BYTES)
check('performance report has no current input', prepared_perf['input'] is None)
for label, response, expected in [
    ('registration import path', import_reg, LIBRARY / 'Warm Comp.b3registration'),
    ('performance import path', import_perf, LIBRARY / 'Warm Performance.b3performance'),
    ('registration materialization path', prepared_reg, DESTINATION / 'Warm Current.b3performance'),
    ('performance materialization path', prepared_perf, DESTINATION / 'Warm Saved.b3performance'),
]:
    encoded = response['save']['path']
    check(label + ' retains exact Unicode POSIX bytes',
          encoded['encoding'] == 'posix-bytes-hex'
          and bytes.fromhex(encoded['value']) == os.fsencode(expected))

check('repeated import refuses NameExists without commit',
      repeat_import['code'] == 'NameExists'
      and repeat_import['committed'] is False)
check('repeated materialization refuses NameExists without commit',
      repeat_materialize['code'] == 'NameExists'
      and repeat_materialize['committed'] is False)
receipt['tool_after'] = file_identity(TOOL)
receipt['source_after'] = {p: file_identity(REPO / p) for p in SOURCE_PATHS}
receipt['pack_after'] = inventory(PACK_ROOT)
receipt['current_after'] = file_identity(CURRENT)
receipt['library_after'] = inventory(LIBRARY)
receipt['destination_after'] = inventory(DESTINATION)
receipt['cwd_final_inventory'] = inventory(CWD)
receipt['git_head_after'] = git('rev-parse', 'HEAD')
check('tool SHA unchanged at end',
      receipt['tool_before']['sha256'] == receipt['tool_after']['sha256'])
check('eleven observed CLI/core/storage source files unchanged',
      receipt['source_before'] == receipt['source_after'])
check('eleven observed CLI/core/storage source files match initial HEAD',
      receipt['git_source_diff_before'] == '')
check('entire supplied pack retains inventory, bytes, modes and mtimes',
      receipt['pack_before'] == receipt['pack_after'])
check('literal current input retains bytes, mode and mtime',
      receipt['current_before'] == receipt['current_after'])
check('selected library unchanged by materialization and refusals',
      receipt['library_after_import'] == receipt['library_after'])
check('materialized outputs unchanged by inspection and refusal',
      receipt['destination_after_materialize'] == receipt['destination_after'])
check('exact final inventory retains original three files plus five supported-layout files without sidecars',
      sorted(receipt['cwd_final_inventory']['files']) == sorted([
          'Current état.b3controls',
          'Ma bibliothèque Ω/Warm Comp.b3registration',
          'Ma bibliothèque Ω/Warm Performance.b3performance',
          'inputs/Current état.b3controls',
          'inputs/Ma bibliothèque Ω/Warm Comp.b3registration',
          'inputs/Ma bibliothèque Ω/Warm Performance.b3performance',
          'outputs/Auditions été/Warm Current.b3performance',
          'outputs/Auditions été/Warm Saved.b3performance',
      ]) and receipt['cwd_final_inventory']['directories'] ==
      ['Ma bibliothèque Ω', 'inputs', 'inputs/Ma bibliothèque Ω', 'outputs', 'outputs/Auditions été'])

receipt['completed_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
receipt['cli_process_count'] = len(receipt['processes'])
receipt['check_count'] = len(receipt['checks'])
receipt['failed_checks'] = [c['name'] for c in receipt['checks'] if not c['passed']]
receipt['all_checks_passed'] = not receipt['failed_checks']
receipt['limitations'] = [
    'One bounded Linux x86_64 CLI journey; no Windows or macOS execution.',
    'No configure/build/CTest, renderer, generator, installer or native browser invocation.',
    'Known local source files and executable hashes are identified; this is not fresh remote or hosted qualification.',
    'No physical instrument, native-device, live-state, accessibility or whole-interface 1:1 acceptance.',
]
write_json(PRIVATE / 'first-use-supported.json', receipt)
write_json(LOGS / 'commands.json', receipt['processes'])
print(json.dumps({'process_count': receipt['cli_process_count'],
                  'check_count': receipt['check_count'],
                  'all_checks_passed': receipt['all_checks_passed'],
                  'failed_checks': receipt['failed_checks']}, indent=2))
