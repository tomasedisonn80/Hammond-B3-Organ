#!/usr/bin/env python3
"""One descriptive baseline/candidate pair; no acceptance threshold."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import signal
import subprocess
import time

repo = Path('/workspace/scratch/3edffb787db3/Hammond-B3-Organ')
out = repo.parent / 'a34-resources'
out.mkdir(exist_ok=True)
reports = repo / 'docs/development/2026-11-16-preset-library-continuation/reports'
sources = ['apps/standalone/Drawing.cpp', 'apps/standalone/Drawing.h',
           'apps/standalone/InstrumentView.cpp', 'tools/standalone_paint_benchmark.cpp',
           'apps/standalone/UiModel.cpp', 'apps/standalone/UiModel.h']
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
hashes = {p: digest(repo / p) for p in sources}
baseline = json.loads((reports / 'baseline-qualification.json').read_text())
candidate = json.loads((reports / 'w04-coherent-qualification.json').read_text())
inputs = [
    ('baseline', '../baseline-native/hammond_standalone_paint_benchmark',
     baseline['artifacts']['hammond_standalone_paint_benchmark']['sha256']),
    ('candidate', '../build-native/apps/standalone/hammond_standalone_paint_benchmark',
     candidate['binaries']['apps/standalone/hammond_standalone_paint_benchmark']),
]
for name, path, expected in inputs:
    assert digest(repo / path) == expected, (name, 'binary identity changed')
assert not (out / 'measurement.json').exists(), 'Preserve the original observation'
cpu = next((line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines()
            if line.startswith('model name')), 'unavailable')
report = {
    'scope': 'One sequential genuine-baseline/candidate canonical software paint measurement; no threshold',
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'cwd': str(repo), 'source_sha256_before': hashes,
    'script_sha256': digest(Path(__file__)),
    'environment': {'platform': platform.platform(), 'cpu': cpu, 'logical_cpus': os.cpu_count(),
                    'affinity_cpus': sorted(os.sched_getaffinity(0)),
                    'load_average_start': os.getloadavg(),
                    'compiler_from_baseline_receipt': baseline['compiler'],
                    'configuration_from_baseline_receipt': baseline['configuration']},
    'results': [],
    'limits': ['Separate processes, baseline first; not randomized or a causal timing attribution.',
               'Linux time peak RSS is whole-process high-water memory, not incremental texture allocation.',
               'No heap instrumentation, GPU/VRAM, callback, display presentation or deadline claim.']
}
for name, binary, expected in inputs:
    arguments = [binary, '1672', '941', 'dimensional', 'mixed-held']
    metrics = out / (name + '-process.json')
    command = ['/usr/bin/time', '-f',
               '{"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S,"peak_rss_kib":%M,"exit_status":%x}',
               '-o', str(metrics)] + arguments
    stdout, stderr = out / (name + '.json'), out / (name + '.stderr')
    assert not stdout.exists() and not stderr.exists() and not metrics.exists()
    started = time.perf_counter()
    with stdout.open('xb') as output, stderr.open('xb') as errors:
        process = subprocess.Popen(command, cwd=repo, stdout=output, stderr=errors, start_new_session=True)
        try:
            status = process.wait(timeout=55)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            raise
    elapsed = time.perf_counter() - started
    assert status == 0 and stderr.stat().st_size == 0, (name, status, stderr.read_text())
    observation = json.loads(stdout.read_text())
    assert observation['paired'] is False and observation['heap_instrumentation'] is False
    assert observation['warmup_each'] == 30 and observation['samples_each'] == 300
    result = {'name': name, 'command': command, 'binary_sha256': expected,
              'binary_bytes': (repo / binary).stat().st_size,
              'python_elapsed_seconds': elapsed, 'process': json.loads(metrics.read_text()),
              'observation': observation,
              'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr),
              'process_sha256': digest(metrics)}
    report['results'].append(result)
    print(json.dumps({'name': name, 'process': result['process'], 'current': {
        k: v for k, v in observation['current'].items() if k != 'samples_total_ns'}}), flush=True)
report['source_sha256_after'] = {p: digest(repo / p) for p in sources}
assert report['source_sha256_before'] == report['source_sha256_after']
report['environment']['load_average_end'] = os.getloadavg()
for key in ['width', 'height', 'presentation', 'scenario', 'overlay', 'workspace', 'renderer',
            'renderer_flags', 'sdl_version', 'surface_format', 'surface_bytes', 'render_batching',
            'scale', 'viewport', 'clip', 'layout_fnv1a64', 'clock', 'clock_period']:
    assert report['results'][0]['observation'][key] == report['results'][1]['observation'][key], key
report['comparable_metadata_equal'] = True
(out / 'measurement.json').write_text(json.dumps(report, indent=2) + '\n')
print('measurement_sha256=' + digest(out / 'measurement.json'), flush=True)
