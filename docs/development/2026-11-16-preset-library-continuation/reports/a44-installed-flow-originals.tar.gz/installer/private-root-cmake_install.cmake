# Install script for directory: /workspace/scratch/3edffb787db3/a44-installed-flow/source

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/workspace/scratch/3edffb787db3/a44-installed-flow/build/apps/standalone/cmake_install.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
          if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
           NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
            message(FATAL_ERROR "OfflineTools requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
        endif()
        set(_hammond_inputs
            "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_render"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_model_info"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_parameter_info"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_console_trace"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_pedal_trace"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/build/nominal.b3p"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/plot_console_trace.py"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/plot_pedal_trace.py"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/catalog-v1.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/a4-fundamental-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/two-manual-changes-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/low-fold-coherent-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/held-bank-cancel-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/high-fold-coherent-v1.events"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/console/console-catalog-v1.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/console/console-travel-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/console/console-percussion-legato-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/console/console-routing-mask-v1.events"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-catalog-v1.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-mixtures-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-shared-source-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-held-routing-v1.events;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-phrase-v1.events")
        foreach(_hammond_input IN LISTS _hammond_inputs)
            if(NOT EXISTS "${_hammond_input}" OR IS_DIRECTORY "${_hammond_input}")
                message(FATAL_ERROR
                    "OfflineTools missing required file '${_hammond_input}'. Build all five executable targets (hammond_render, hammond_model_info, hammond_parameter_info, hammond_console_trace, hammond_pedal_trace), nominal.b3p and retain both source plot scripts/catalogs/scores for the selected configuration before installing.")
            endif()
        endforeach()
    
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_render" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_render")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_render"
         RPATH "")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_render")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_render" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_render")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_render")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_model_info" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_model_info")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_model_info"
         RPATH "")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_model_info")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_model_info" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_model_info")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_model_info")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_parameter_info" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_parameter_info")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_parameter_info"
         RPATH "")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_parameter_info")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_parameter_info" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_parameter_info")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_parameter_info")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_console_trace" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_console_trace")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_console_trace"
         RPATH "")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_console_trace")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_console_trace" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_console_trace")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_console_trace")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_pedal_trace" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_pedal_trace")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_pedal_trace"
         RPATH "")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_pedal_trace")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_pedal_trace" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_pedal_trace")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_pedal_trace")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE PROGRAM FILES
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/plot_console_trace.py"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/plot_pedal_trace.py"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/nominal.b3p")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/fixtures" TYPE FILE FILES
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/catalog-v1.json"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/a4-fundamental-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/two-manual-changes-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/low-fold-coherent-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/held-bank-cancel-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/high-fold-coherent-v1.events"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/fixtures/console" TYPE FILE FILES
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/console/console-catalog-v1.json"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/console/console-travel-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/console/console-percussion-legato-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/console/console-routing-mask-v1.events"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "OfflineTools" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/fixtures/pedals" TYPE FILE FILES
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-catalog-v1.json"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-mixtures-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-shared-source-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-held-routing-v1.events"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/fixtures/pedals/pedal-phrase-v1.events"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "RegistrationTools")
          set(_hammond_registration_component RegistrationTools)
            if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
       NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
        message(FATAL_ERROR "${_hammond_registration_component} requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
    endif()
    function(_hammond_registration_require_input input root)
        if(NOT EXISTS "${input}" OR IS_DIRECTORY "${input}" OR IS_SYMLINK "${input}")
            message(FATAL_ERROR "${_hammond_registration_component} missing or invalid required input '${input}'; retain every nonempty nonsymlink component input before installing.")
        endif()
        file(SIZE "${input}" input_size)
        if(input_size EQUAL 0)
            message(FATAL_ERROR "${_hammond_registration_component} required input is empty: '${input}'.")
        endif()
        get_filename_component(parent "${input}" DIRECTORY)
        while(1)
            if(IS_SYMLINK "${parent}" OR NOT IS_DIRECTORY "${parent}")
                message(FATAL_ERROR "${_hammond_registration_component} source ancestor must be an ordinary directory: '${parent}'.")
            endif()
            if(parent STREQUAL root)
                break()
            endif()
            get_filename_component(next_parent "${parent}" DIRECTORY)
            if(next_parent STREQUAL parent)
                break()
            endif()
            set(parent "${next_parent}")
        endwhile()
        # Read every admitted input before copying any of them. This detects
        # unreadable regular files without parsing or executing their contents.
        file(SHA256 "${input}" input_readability_sha256)
    endfunction()
    get_filename_component(_hammond_registration_prefix "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}" ABSOLUTE)
    function(_hammond_registration_require_destination destination)
        if(EXISTS "${destination}" OR IS_SYMLINK "${destination}")
            message(FATAL_ERROR "${_hammond_registration_component} destination already exists: '${destination}'. Choose a fresh destination; existing files or packages are never replaced or merged.")
        endif()
        # Inspect the effective prefix itself and all ancestors inside it. Trust
        # system ancestors outside the caller's prefix, as other components do.
        get_filename_component(parent "${destination}" DIRECTORY)
        while(1)
            if(IS_SYMLINK "${parent}" OR (EXISTS "${parent}" AND NOT IS_DIRECTORY "${parent}"))
                message(FATAL_ERROR "${_hammond_registration_component} destination ancestor must be an ordinary directory: '${parent}'.")
            endif()
            if(parent STREQUAL _hammond_registration_prefix)
                break()
            endif()
            get_filename_component(next_parent "${parent}" DIRECTORY)
            if(next_parent STREQUAL parent)
                break()
            endif()
            set(parent "${next_parent}")
        endwhile()
    endfunction()

        _hammond_registration_require_input("/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_registration" [==[/workspace/scratch/3edffb787db3/a44-installed-flow/build]==])
        _hammond_registration_require_input([==[/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/REGISTRATION_GUIDE.md]==]
            [==[/workspace/scratch/3edffb787db3/a44-installed-flow/source]==])
        get_filename_component(binary_destination
            "${_hammond_registration_prefix}/bin/hammond_registration" ABSOLUTE)
        get_filename_component(guide_destination
            "${_hammond_registration_prefix}/share/hammond/REGISTRATION_GUIDE.md" ABSOLUTE)
        # Each destination is a file; neither can also contain the other.
        foreach(first binary_destination guide_destination)
            foreach(second binary_destination guide_destination)
                if(NOT first STREQUAL second)
                    file(RELATIVE_PATH relative "${${first}}" "${${second}}")
                    if(NOT IS_ABSOLUTE "${relative}" AND NOT relative MATCHES "^\\.\\.(/|$)")
                        message(FATAL_ERROR "RegistrationTools executable and guide destinations conflict.")
                    endif()
                endif()
            endforeach()
        endforeach()
        _hammond_registration_require_destination("${binary_destination}")
        _hammond_registration_require_destination("${guide_destination}")
        message(STATUS "RegistrationTools preflight passed; copying begins. A later failure can leave a partial new installation; no automatic cleanup is performed.")
    
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "RegistrationTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE PROGRAM FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "RegistrationTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/REGISTRATION_GUIDE.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
      set(_hammond_registration_component StarterRegistrations)
        if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
       NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
        message(FATAL_ERROR "${_hammond_registration_component} requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
    endif()
    function(_hammond_registration_require_input input root)
        if(NOT EXISTS "${input}" OR IS_DIRECTORY "${input}" OR IS_SYMLINK "${input}")
            message(FATAL_ERROR "${_hammond_registration_component} missing or invalid required input '${input}'; retain every nonempty nonsymlink component input before installing.")
        endif()
        file(SIZE "${input}" input_size)
        if(input_size EQUAL 0)
            message(FATAL_ERROR "${_hammond_registration_component} required input is empty: '${input}'.")
        endif()
        get_filename_component(parent "${input}" DIRECTORY)
        while(1)
            if(IS_SYMLINK "${parent}" OR NOT IS_DIRECTORY "${parent}")
                message(FATAL_ERROR "${_hammond_registration_component} source ancestor must be an ordinary directory: '${parent}'.")
            endif()
            if(parent STREQUAL root)
                break()
            endif()
            get_filename_component(next_parent "${parent}" DIRECTORY)
            if(next_parent STREQUAL parent)
                break()
            endif()
            set(parent "${next_parent}")
        endwhile()
        # Read every admitted input before copying any of them. This detects
        # unreadable regular files without parsing or executing their contents.
        file(SHA256 "${input}" input_readability_sha256)
    endfunction()
    get_filename_component(_hammond_registration_prefix "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}" ABSOLUTE)
    function(_hammond_registration_require_destination destination)
        if(EXISTS "${destination}" OR IS_SYMLINK "${destination}")
            message(FATAL_ERROR "${_hammond_registration_component} destination already exists: '${destination}'. Choose a fresh destination; existing files or packages are never replaced or merged.")
        endif()
        # Inspect the effective prefix itself and all ancestors inside it. Trust
        # system ancestors outside the caller's prefix, as other components do.
        get_filename_component(parent "${destination}" DIRECTORY)
        while(1)
            if(IS_SYMLINK "${parent}" OR (EXISTS "${parent}" AND NOT IS_DIRECTORY "${parent}"))
                message(FATAL_ERROR "${_hammond_registration_component} destination ancestor must be an ordinary directory: '${parent}'.")
            endif()
            if(parent STREQUAL _hammond_registration_prefix)
                break()
            endif()
            get_filename_component(next_parent "${parent}" DIRECTORY)
            if(next_parent STREQUAL parent)
                break()
            endif()
            set(parent "${next_parent}")
        endwhile()
    endfunction()

    set(entries [==[01 Quiet Foundation.b3registration;01 Quiet Foundation.b3performance;02 Warm Comp.b3registration;02 Warm Comp.b3performance;03 Clear Lead.b3registration;03 Clear Lead.b3performance;04 Reed Edge.b3registration;04 Reed Edge.b3performance;05 Bright Ensemble.b3registration;05 Bright Ensemble.b3performance;06 High Shimmer.b3registration;06 High Shimmer.b3performance;07 Percussive Pair.b3registration;07 Percussive Pair.b3performance;08 Slow Accent.b3registration;08 Slow Accent.b3performance;09 Split Dialogue.b3registration;09 Split Dialogue.b3performance;10 Pedal Study.b3registration;10 Pedal Study.b3performance;11 Fixed Contrast.b3registration;11 Fixed Contrast.b3performance;12 Manual Return.b3registration;12 Manual Return.b3performance]==])
    foreach(entry IN LISTS entries)
        _hammond_registration_require_input("/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/${entry}"
            [==[/workspace/scratch/3edffb787db3/a44-installed-flow/source]==])
    endforeach()
    foreach(metadata README.md recipes.json)
        _hammond_registration_require_input("/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/${metadata}"
            [==[/workspace/scratch/3edffb787db3/a44-installed-flow/source]==])
    endforeach()
    get_filename_component(destination "${_hammond_registration_prefix}/share/hammond/registrations/starter-v1" ABSOLUTE)
    _hammond_registration_require_destination("${destination}")
    message(STATUS "StarterRegistrations preflight passed; copying begins. A later failure can leave a partial new installation; no automatic cleanup is performed.")

endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/01 Quiet Foundation.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/01 Quiet Foundation.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/02 Warm Comp.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/02 Warm Comp.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/03 Clear Lead.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/03 Clear Lead.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/04 Reed Edge.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/04 Reed Edge.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/05 Bright Ensemble.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/05 Bright Ensemble.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/06 High Shimmer.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/06 High Shimmer.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/07 Percussive Pair.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/07 Percussive Pair.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/08 Slow Accent.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/08 Slow Accent.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/09 Split Dialogue.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/09 Split Dialogue.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/10 Pedal Study.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/10 Pedal Study.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/11 Fixed Contrast.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/11 Fixed Contrast.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/12 Manual Return.b3registration")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1/entries" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/entries/12 Manual Return.b3performance")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "StarterRegistrations")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond/registrations/starter-v1" TYPE FILE FILES
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/README.md"
    "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/registrations/starter-v1/recipes.json"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
      if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
       NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
        message(FATAL_ERROR "ContactReferenceTools requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
    endif()
    set(_hammond_contact_source [==[/workspace/scratch/3edffb787db3/a44-installed-flow/source]==])
    set(_hammond_contact_files [==[tools/fractional_contact_reference.py;tools/contact_switching_io.py;tools/contact_switching_reference.py;tools/contact_switching_oracle.py;tools/contact_switching_study.py;tools/make_contact_switching_fixtures.py;docs/FRACTIONAL_CONTACT_REFERENCE.md;docs/CONTACT_SWITCHING_VALIDATION.md;docs/CONTACT_SWITCHING_GUIDE.md;docs/CONTACT_REFERENCE_INSTALL.md;data/contact-switching/reference-v1/F00-44100-v1.json;data/contact-switching/reference-v1/F00-48000-v1.json;data/contact-switching/reference-v1/F00-96000-v1.json;data/contact-switching/reference-v1/F01-44100-v1.json;data/contact-switching/reference-v1/F01-48000-v1.json;data/contact-switching/reference-v1/F01-96000-v1.json;data/contact-switching/reference-v1/F02-44100-v1.json;data/contact-switching/reference-v1/F02-48000-v1.json;data/contact-switching/reference-v1/F02-96000-v1.json;data/contact-switching/reference-v1/F03-44100-v1.json;data/contact-switching/reference-v1/F03-48000-v1.json;data/contact-switching/reference-v1/F03-96000-v1.json;data/contact-switching/reference-v1/F04-44100-v1.json;data/contact-switching/reference-v1/F04-48000-v1.json;data/contact-switching/reference-v1/F04-96000-v1.json;data/contact-switching/reference-v1/F05-44100-v1.json;data/contact-switching/reference-v1/F05-48000-v1.json;data/contact-switching/reference-v1/F05-96000-v1.json;data/contact-switching/reference-v1/F06-44100-v1.json;data/contact-switching/reference-v1/F06-48000-v1.json;data/contact-switching/reference-v1/F06-96000-v1.json;data/contact-switching/reference-v1/F07-44100-v1.json;data/contact-switching/reference-v1/F07-48000-v1.json;data/contact-switching/reference-v1/F07-96000-v1.json;data/contact-switching/reference-v1/F08-44100-v1.json;data/contact-switching/reference-v1/F08-48000-v1.json;data/contact-switching/reference-v1/F08-96000-v1.json;data/contact-switching/reference-v1/F09-44100-v1.json;data/contact-switching/reference-v1/F09-48000-v1.json;data/contact-switching/reference-v1/F09-96000-v1.json;data/contact-switching/reference-v1/F10-44100-v1.json;data/contact-switching/reference-v1/F10-48000-v1.json;data/contact-switching/reference-v1/F10-96000-v1.json;data/contact-switching/reference-v1/F11-44100-v1.json;data/contact-switching/reference-v1/F11-48000-v1.json;data/contact-switching/reference-v1/F11-96000-v1.json;data/contact-switching/reference-v1/manifest.json;data/contact-switching/reference-v1/probes.json]==])
    foreach(_hammond_contact_relative IN LISTS _hammond_contact_files)
        set(_hammond_contact_input "${_hammond_contact_source}/${_hammond_contact_relative}")
        if(NOT EXISTS "${_hammond_contact_input}" OR
           IS_DIRECTORY "${_hammond_contact_input}" OR
           IS_SYMLINK "${_hammond_contact_input}")
            message(FATAL_ERROR
                "ContactReferenceTools missing or invalid required input '${_hammond_contact_input}'; retain all 48 nonempty nonsymlink source payload files before installing.")
        endif()
        file(SIZE "${_hammond_contact_input}" _hammond_contact_size)
        if(_hammond_contact_size EQUAL 0)
            message(FATAL_ERROR "ContactReferenceTools required input is empty: '${_hammond_contact_input}'.")
        endif()
        # A nonsymlink leaf must not conceal a linked directory inside the
        # source root. Trust system ancestors outside that root.
        get_filename_component(_hammond_contact_parent "${_hammond_contact_input}" DIRECTORY)
        while(1)
            if(IS_SYMLINK "${_hammond_contact_parent}" OR
               NOT IS_DIRECTORY "${_hammond_contact_parent}")
                message(FATAL_ERROR
                    "ContactReferenceTools source ancestor must be an ordinary directory: '${_hammond_contact_parent}'.")
            endif()
            if(_hammond_contact_parent STREQUAL _hammond_contact_source)
                break()
            endif()
            get_filename_component(_hammond_contact_next_parent
                "${_hammond_contact_parent}" DIRECTORY)
            if(_hammond_contact_next_parent STREQUAL _hammond_contact_parent)
                break()
            endif()
            set(_hammond_contact_parent "${_hammond_contact_next_parent}")
        endwhile()
    endforeach()

    get_filename_component(_hammond_contact_prefix
        "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}" ABSOLUTE)
    get_filename_component(_hammond_contact_destination
        "${_hammond_contact_prefix}/share/hammond-b3-organ/contact-reference" ABSOLUTE)
    if(EXISTS "${_hammond_contact_destination}" OR
       IS_SYMLINK "${_hammond_contact_destination}")
        message(FATAL_ERROR
            "ContactReferenceTools destination already exists: '${_hammond_contact_destination}'. Choose a fresh local prefix; existing packages are never replaced or merged.")
    endif()
    # Check all ancestors inside the chosen (possibly DESTDIR-staged) prefix,
    # including the prefix itself, before the first destination write.
    # System ancestors outside the caller's prefix are not inspected.
    get_filename_component(_hammond_contact_parent
        "${_hammond_contact_destination}" DIRECTORY)
    while(1)
        if(IS_SYMLINK "${_hammond_contact_parent}" OR
           (EXISTS "${_hammond_contact_parent}" AND
            NOT IS_DIRECTORY "${_hammond_contact_parent}"))
            message(FATAL_ERROR
                "ContactReferenceTools destination ancestor must be an ordinary directory: '${_hammond_contact_parent}'.")
        endif()
        if(_hammond_contact_parent STREQUAL _hammond_contact_prefix)
            break()
        endif()
        get_filename_component(_hammond_contact_next_parent
            "${_hammond_contact_parent}" DIRECTORY)
        if(_hammond_contact_next_parent STREQUAL _hammond_contact_parent)
            break()
        endif()
        set(_hammond_contact_parent "${_hammond_contact_next_parent}")
    endwhile()
    message(STATUS
        "ContactReferenceTools preflight passed; copying begins. A later failure can leave a partial new installation; no automatic cleanup is performed.")

endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/fractional_contact_reference.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/contact_switching_io.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/contact_switching_reference.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/contact_switching_oracle.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/contact_switching_study.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/make_contact_switching_fixtures.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/FRACTIONAL_CONTACT_REFERENCE.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CONTACT_SWITCHING_VALIDATION.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CONTACT_SWITCHING_GUIDE.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CONTACT_REFERENCE_INSTALL.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F00-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F00-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F00-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F01-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F01-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F01-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F02-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F02-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F02-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F03-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F03-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F03-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F04-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F04-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F04-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F05-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F05-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F05-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F06-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F06-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F06-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F07-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F07-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F07-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F08-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F08-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F08-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F09-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F09-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F09-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F10-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F10-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F10-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F11-44100-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F11-48000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/F11-96000-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/manifest.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactReferenceTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-reference/data/contact-switching/reference-v1" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/contact-switching/reference-v1/probes.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactGridConversionTools")
      if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
       NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
        message(FATAL_ERROR "ContactGridConversionTools requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
    endif()
    set(_hammond_contact_grid_conversion_source [==[/workspace/scratch/3edffb787db3/a44-installed-flow/source]==])
    set(_hammond_contact_grid_conversion_files [==[tools/contact_grid_conversion.py;tools/convert_contact_grid.py;tools/contact_switching_io.py;tools/fractional_contact_reference.py;docs/CONTACT_GRID_CONVERSION_CONTRACT.md]==])
    foreach(_hammond_contact_grid_conversion_relative IN LISTS _hammond_contact_grid_conversion_files)
        set(_hammond_contact_grid_conversion_input "${_hammond_contact_grid_conversion_source}/${_hammond_contact_grid_conversion_relative}")
        if(NOT EXISTS "${_hammond_contact_grid_conversion_input}" OR
           IS_DIRECTORY "${_hammond_contact_grid_conversion_input}" OR
           IS_SYMLINK "${_hammond_contact_grid_conversion_input}")
            message(FATAL_ERROR
                "ContactGridConversionTools missing or invalid required input '${_hammond_contact_grid_conversion_input}'; retain all 5 nonempty nonsymlink source payload files before installing.")
        endif()
        file(SIZE "${_hammond_contact_grid_conversion_input}" _hammond_contact_grid_conversion_size)
        if(_hammond_contact_grid_conversion_size EQUAL 0)
            message(FATAL_ERROR "ContactGridConversionTools required input is empty: '${_hammond_contact_grid_conversion_input}'.")
        endif()
        # A nonsymlink leaf must not conceal a linked directory inside the
        # source root. Trust system ancestors outside that root.
        get_filename_component(_hammond_contact_grid_conversion_parent "${_hammond_contact_grid_conversion_input}" DIRECTORY)
        while(1)
            if(IS_SYMLINK "${_hammond_contact_grid_conversion_parent}" OR
               NOT IS_DIRECTORY "${_hammond_contact_grid_conversion_parent}")
                message(FATAL_ERROR
                    "ContactGridConversionTools source ancestor must be an ordinary directory: '${_hammond_contact_grid_conversion_parent}'.")
            endif()
            if(_hammond_contact_grid_conversion_parent STREQUAL _hammond_contact_grid_conversion_source)
                break()
            endif()
            get_filename_component(_hammond_contact_grid_conversion_next_parent
                "${_hammond_contact_grid_conversion_parent}" DIRECTORY)
            if(_hammond_contact_grid_conversion_next_parent STREQUAL _hammond_contact_grid_conversion_parent)
                break()
            endif()
            set(_hammond_contact_grid_conversion_parent "${_hammond_contact_grid_conversion_next_parent}")
        endwhile()
    endforeach()

    get_filename_component(_hammond_contact_grid_conversion_prefix
        "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}" ABSOLUTE)
    get_filename_component(_hammond_contact_grid_conversion_destination
        "${_hammond_contact_grid_conversion_prefix}/share/hammond-b3-organ/contact-grid-conversion" ABSOLUTE)
    if(EXISTS "${_hammond_contact_grid_conversion_destination}" OR
       IS_SYMLINK "${_hammond_contact_grid_conversion_destination}")
        message(FATAL_ERROR
            "ContactGridConversionTools destination already exists: '${_hammond_contact_grid_conversion_destination}'. Choose a fresh local prefix; existing packages are never replaced or merged.")
    endif()
    # Check all ancestors inside the chosen (possibly DESTDIR-staged) prefix,
    # including the prefix itself, before the first destination write.
    # System ancestors outside the caller's prefix are not inspected.
    get_filename_component(_hammond_contact_grid_conversion_parent
        "${_hammond_contact_grid_conversion_destination}" DIRECTORY)
    while(1)
        if(IS_SYMLINK "${_hammond_contact_grid_conversion_parent}" OR
           (EXISTS "${_hammond_contact_grid_conversion_parent}" AND
            NOT IS_DIRECTORY "${_hammond_contact_grid_conversion_parent}"))
            message(FATAL_ERROR
                "ContactGridConversionTools destination ancestor must be an ordinary directory: '${_hammond_contact_grid_conversion_parent}'.")
        endif()
        if(_hammond_contact_grid_conversion_parent STREQUAL _hammond_contact_grid_conversion_prefix)
            break()
        endif()
        get_filename_component(_hammond_contact_grid_conversion_next_parent
            "${_hammond_contact_grid_conversion_parent}" DIRECTORY)
        if(_hammond_contact_grid_conversion_next_parent STREQUAL _hammond_contact_grid_conversion_parent)
            break()
        endif()
        set(_hammond_contact_grid_conversion_parent "${_hammond_contact_grid_conversion_next_parent}")
    endwhile()
    message(STATUS
        "ContactGridConversionTools preflight passed; copying begins. A later failure can leave a partial new installation; no automatic cleanup is performed.")

endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactGridConversionTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-grid-conversion/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/contact_grid_conversion.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactGridConversionTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-grid-conversion/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/convert_contact_grid.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactGridConversionTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-grid-conversion/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/contact_switching_io.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactGridConversionTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-grid-conversion/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/fractional_contact_reference.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ContactGridConversionTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/contact-grid-conversion/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CONTACT_GRID_CONVERSION_CONTRACT.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
          if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
           NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
            message(FATAL_ERROR "SourceLeakageTools requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
        endif()
        set(_hammond_leakage_inputs "/workspace/scratch/3edffb787db3/a44-installed-flow/build/nominal.b3p;/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_render;/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_source_leakage_probe;/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_source_leakage_benchmark;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/compile_source_leakage.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/source-leakage.schema.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/source-leakage/synthetic-pair-demo-v1.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/source-leakage/synthetic-identity-v1.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/SOURCE_LEAKAGE_INSTALL.md")
        foreach(_hammond_leakage_input IN LISTS _hammond_leakage_inputs)
            if(NOT EXISTS "${_hammond_leakage_input}" OR
               IS_DIRECTORY "${_hammond_leakage_input}" OR
               IS_SYMLINK "${_hammond_leakage_input}")
                message(FATAL_ERROR
                    "SourceLeakageTools missing or invalid required input '${_hammond_leakage_input}'; require a nonempty nonsymlink file. Build hammond_render, hammond_source_leakage_probe, hammond_source_leakage_benchmark and nominal.b3p for the selected configuration, and retain all five source payload files.")
            endif()
            file(SIZE "${_hammond_leakage_input}" _hammond_leakage_input_size)
            if(_hammond_leakage_input_size EQUAL 0)
                message(FATAL_ERROR "SourceLeakageTools required input is empty: '${_hammond_leakage_input}'.")
            endif()
        endforeach()

        get_filename_component(_hammond_leakage_prefix
            "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}" ABSOLUTE)
        set(_hammond_leakage_destinations
            "${_hammond_leakage_prefix}/share/hammond-b3-organ/source-leakage")
        set(_hammond_leakage_binary_names "hammond_render;hammond_source_leakage_probe;hammond_source_leakage_benchmark")
        foreach(_hammond_leakage_name IN LISTS _hammond_leakage_binary_names)
            list(APPEND _hammond_leakage_destinations
                "${_hammond_leakage_prefix}/bin/${_hammond_leakage_name}")
        endforeach()
        foreach(_hammond_leakage_destination IN LISTS _hammond_leakage_destinations)
            if(EXISTS "${_hammond_leakage_destination}" OR
               IS_SYMLINK "${_hammond_leakage_destination}")
                message(FATAL_ERROR
                    "SourceLeakageTools destination already exists: '${_hammond_leakage_destination}'. Choose a fresh local prefix; existing executable files and source-leakage packages are never replaced or merged.")
            endif()
            # Reject obstructions and linked ancestors inside the chosen prefix
            # before the first copy. System ancestors outside it are not policed.
            get_filename_component(_hammond_leakage_parent
                "${_hammond_leakage_destination}" DIRECTORY)
            while(1)
                if(IS_SYMLINK "${_hammond_leakage_parent}" OR
                   (EXISTS "${_hammond_leakage_parent}" AND
                    NOT IS_DIRECTORY "${_hammond_leakage_parent}"))
                    message(FATAL_ERROR
                        "SourceLeakageTools destination ancestor must be an ordinary directory: '${_hammond_leakage_parent}'.")
                endif()
                if(_hammond_leakage_parent STREQUAL _hammond_leakage_prefix)
                    break()
                endif()
                get_filename_component(_hammond_leakage_next_parent
                    "${_hammond_leakage_parent}" DIRECTORY)
                if(_hammond_leakage_next_parent STREQUAL _hammond_leakage_parent)
                    break()
                endif()
                set(_hammond_leakage_parent "${_hammond_leakage_next_parent}")
            endwhile()
        endforeach()
        message(STATUS
            "SourceLeakageTools preflight passed; copying begins. A later failure can leave a partial new installation; no automatic cleanup is performed.")
    
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE PROGRAM FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_render")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE PROGRAM FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_source_leakage_probe")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE PROGRAM FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_source_leakage_benchmark")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/source-leakage/profiles" TYPE FILE RENAME "nominal.b3p" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/nominal.b3p")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/source-leakage/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/compile_source_leakage.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/source-leakage/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/source-leakage.schema.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/source-leakage/data/source-leakage" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/source-leakage/synthetic-pair-demo-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/source-leakage/data/source-leakage" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/source-leakage/synthetic-identity-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "SourceLeakageTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/source-leakage/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/SOURCE_LEAKAGE_INSTALL.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CrossoverTools")
          if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
           NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
            message(FATAL_ERROR "CrossoverTools requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
        endif()
        set(_hammond_crossover_inputs "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_crossover_probe;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/crossover_reference.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/crossover/leslie-122-ideal-v1.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CROSSOVER_INSTALL.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/LESLIE_CROSSOVER_CONTRACT.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/THIRD_PARTY_NOTICES.md")
        foreach(_hammond_crossover_input IN LISTS _hammond_crossover_inputs)
            if(NOT EXISTS "${_hammond_crossover_input}" OR
               IS_DIRECTORY "${_hammond_crossover_input}" OR
               IS_SYMLINK "${_hammond_crossover_input}")
                message(FATAL_ERROR
                    "CrossoverTools missing or invalid required input '${_hammond_crossover_input}'; require a nonempty nonsymlink file. Build hammond_crossover_probe for the selected configuration and retain all five source payload files before installing.")
            endif()
            file(SIZE "${_hammond_crossover_input}" _hammond_crossover_input_size)
            if(_hammond_crossover_input_size EQUAL 0)
                message(FATAL_ERROR "CrossoverTools required input is empty: '${_hammond_crossover_input}'.")
            endif()
        endforeach()

        get_filename_component(_hammond_crossover_prefix
            "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}" ABSOLUTE)
        set(_hammond_crossover_binary
            "${_hammond_crossover_prefix}/bin/hammond_crossover_probe")
        set(_hammond_crossover_leaf
            "${_hammond_crossover_prefix}/share/hammond-b3-organ/crossover")
        foreach(_hammond_crossover_destination IN ITEMS
                "${_hammond_crossover_binary}" "${_hammond_crossover_leaf}")
            if(EXISTS "${_hammond_crossover_destination}" OR
               IS_SYMLINK "${_hammond_crossover_destination}")
                message(FATAL_ERROR
                    "CrossoverTools destination already exists: '${_hammond_crossover_destination}'. Choose a fresh local prefix; existing probe files and crossover packages are never replaced or merged.")
            endif()
            # Reject known obstructions before the first copy, including a
            # linked prefix or an output ancestor that would redirect writes.
            # System ancestors outside the caller's prefix are not inspected.
            get_filename_component(_hammond_crossover_parent
                "${_hammond_crossover_destination}" DIRECTORY)
            # Install scripts do not inherit the configure-time policy scope.
            # Numeric truth remains valid when older CMake leaves CMP0012 unset.
            while(1)
                if(IS_SYMLINK "${_hammond_crossover_parent}" OR
                   (EXISTS "${_hammond_crossover_parent}" AND
                    NOT IS_DIRECTORY "${_hammond_crossover_parent}"))
                    message(FATAL_ERROR
                        "CrossoverTools destination ancestor must be an ordinary directory: '${_hammond_crossover_parent}'.")
                endif()
                if(_hammond_crossover_parent STREQUAL _hammond_crossover_prefix)
                    break()
                endif()
                get_filename_component(_hammond_crossover_next_parent
                    "${_hammond_crossover_parent}" DIRECTORY)
                if(_hammond_crossover_next_parent STREQUAL _hammond_crossover_parent)
                    break()
                endif()
                set(_hammond_crossover_parent "${_hammond_crossover_next_parent}")
            endwhile()
        endforeach()
        message(STATUS
            "CrossoverTools preflight passed; copying begins. A later failure can leave a partial new installation; no automatic cleanup is performed.")
    
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CrossoverTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE PROGRAM FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/hammond_crossover_probe")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CrossoverTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/crossover/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/crossover_reference.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CrossoverTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/crossover/data/crossover" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/crossover/leslie-122-ideal-v1.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CrossoverTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/crossover/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CROSSOVER_INSTALL.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CrossoverTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/crossover/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/LESLIE_CROSSOVER_CONTRACT.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CrossoverTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/crossover" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/THIRD_PARTY_NOTICES.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
      if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
       NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
        message(FATAL_ERROR "CaptureTools requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
    endif()
    set(_hammond_capture_inputs "/workspace/scratch/3edffb787db3/a44-installed-flow/build/capture-tools-install/README.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/validate_capture.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_common.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_audio.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_corpus.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/compare_capture.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_job.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_readiness.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_study.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/make_capture_demo.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/verify_capture_report.py;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture.schema.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-corpus.schema.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-policy.schema.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-job.schema.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-study.schema.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-planned-example.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/corpus-planned-example.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-policy-synthetic-example.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_FORMAT.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_PROTOCOL.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_VALIDATION.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_COMMON.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_AUDIO_CONTRACT.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_AUDIO.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_CORPUS_CONTRACT.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_CORPUS.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_COMPARISON_CONTRACT.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_COMPARISON.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_POLICY.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_JOB_CONTRACT.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_JOB.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_READINESS.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_STUDY.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_DEMO.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_REPLAY.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_TOOLS_INSTALL.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/PLAN.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CALIBRATION_SCOPE.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_JOB_REVIEW.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/README.md;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/EXPECTED.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/study.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/job-pass.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/job-inconclusive.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/job-fail.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/policy-pass.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/policy-inconclusive.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/policy-fail.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/corpus.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/reference.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/quarter.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/half.json;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/audio/reference.f32;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/audio/quarter.f32;/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/audio/half.f32;/workspace/scratch/3edffb787db3/a44-installed-flow/source/THIRD_PARTY_NOTICES.md")
    foreach(_hammond_capture_input IN LISTS _hammond_capture_inputs)
        if(NOT EXISTS "${_hammond_capture_input}" OR
           IS_DIRECTORY "${_hammond_capture_input}" OR
           IS_SYMLINK "${_hammond_capture_input}")
            message(FATAL_ERROR
                "CaptureTools requires every payload input as an existing nonsymlink file: '${_hammond_capture_input}'. Retain the complete source package and configure again before installing.")
        endif()
        file(SIZE "${_hammond_capture_input}" _hammond_capture_input_size)
        if(_hammond_capture_input_size EQUAL 0)
            message(FATAL_ERROR "CaptureTools payload input is empty: '${_hammond_capture_input}'.")
        endif()
    endforeach()
    set(_hammond_capture_leaf
        "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools")
    if(EXISTS "${_hammond_capture_leaf}" OR IS_SYMLINK "${_hammond_capture_leaf}")
        message(FATAL_ERROR
            "CaptureTools destination already exists: '${_hammond_capture_leaf}'. Choose a fresh package root; existing packages are not merged or replaced.")
    endif()
    message(STATUS
        "CaptureTools preflight passed; copying begins. A later failure may retain a partial new package at '${_hammond_capture_leaf}'; no automatic cleanup is performed.")

endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/capture-tools-install/README.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/validate_capture.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_common.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_audio.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_corpus.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/compare_capture.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_job.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_readiness.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/capture_study.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/make_capture_demo.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/tools/verify_capture_report.py")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture.schema.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-corpus.schema.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-policy.schema.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-job.schema.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-study.schema.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-planned-example.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/corpus-planned-example.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/data" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/capture-policy-synthetic-example.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_FORMAT.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_PROTOCOL.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_VALIDATION.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_COMMON.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_AUDIO_CONTRACT.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_AUDIO.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_CORPUS_CONTRACT.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_CORPUS.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_COMPARISON_CONTRACT.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_COMPARISON.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_POLICY.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_JOB_CONTRACT.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_JOB.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_READINESS.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_STUDY.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_DEMO.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_REPLAY.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_TOOLS_INSTALL.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/PLAN.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CALIBRATION_SCOPE.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/docs" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/CAPTURE_JOB_REVIEW.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/README.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/EXPECTED.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/study.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/job-pass.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/job-inconclusive.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/job-fail.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/policy-pass.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/policy-inconclusive.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/policy-fail.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo/corpus" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/corpus.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo/corpus" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/reference.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo/corpus" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/quarter.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo/corpus" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/half.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo/corpus/audio" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/audio/reference.f32")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo/corpus/audio" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/audio/quarter.f32")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools/examples/capture-demo/corpus/audio" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/examples/capture-demo/corpus/audio/half.f32")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "CaptureTools")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/capture-tools" TYPE FILE FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/THIRD_PARTY_NOTICES.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
          if(DEFINED ENV{CMAKE_INSTALL_MODE} AND NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "" AND
           NOT "$ENV{CMAKE_INSTALL_MODE}" STREQUAL "COPY")
            message(FATAL_ERROR "Standalone requires CMAKE_INSTALL_MODE=COPY (or unset) for relocation.")
        endif()
        set(_hammond_standalone_inputs
            "/workspace/scratch/3edffb787db3/a44-installed-flow/build/apps/standalone/hammond_standalone"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/STANDALONE_INSTALL.md"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/STANDALONE_APP.md"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/STANDALONE_MODEL.md"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/MIDI_UI_RUNBOOK.md"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/PRESET_RUNBOOK.md"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/INTERFACE_RUNBOOK.md"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/THIRD_PARTY_NOTICES.md"
            "/workspace/scratch/ade21b726509/SDL2/LICENSE.txt"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/assets/standalone/fonts/LICENSE-DejaVu.txt"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/dependencies/sdl2-lock.json"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/assets/standalone/fonts/source-manifest.json"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/assets/standalone/reference/manifest.json"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/design/atlas-reference.json"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/build/generated/standalone-capabilities.json"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/MIDI_EXPRESSION_GUIDE.md"
            "/workspace/scratch/3edffb787db3/a44-installed-flow/source/assets/standalone/reference-apron-v1/manifest.json"
            )
        # lstat distinguishes ordinary files from FIFOs/devices as well as
        # directories and dangling symlinks, without opening a special file.
        # This entire read-only preflight precedes the first destination write.
        execute_process(COMMAND "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "-c" [==[
import hashlib
import os
from pathlib import Path
import stat
import sys

def reject(message):
    raise SystemExit("Standalone " + message)

inputs = [Path(value) for value in sys.argv[1:-2]]
expected_hashes = "a4ad208456b4ed3521c24050d2d9d9a877662ae8ff3e96cff00ef388be1e8cba;1b811ae61e58e0429d77942f70e189c402ce13082a49f183aa5204d342a14262;4a55fa2437c3b988f8ecfa347ea8122d72002504b3bde3420d128783215f31f3;e519fec270928c864f358e617a7750de8968ef02786c8c6a7b7261d0031c63e9;8a2a8a2eed10ff69871e86a2d914ad9278d03433ed96e8c621fe6730b2e29cde;a9e87298b9ab14564b9799d23b872f978bbda1d759bfe2c9ce85be5f06c00674;3fbf149e1e5636e21c4ebffbd27c82b66fbc6131fb87a0cca3a355391fa8b43b;97f35b302b361680ec1e891e95d2d52097bb95abff361434916d99dc1305f127;22308e512b54800ba9fe6f9aecd6bea42b71f68f77dbc83196715aac50e631d6;ddc78f8cbe3deea26a71109f24e4121551af798f8347bbc3f6fabb8f87950e84;8bc668338513949846f758db5acd170dc6f73977fc14b8ba5f113a062740d4eb;bf1bec09c0dd15d09ab0129f950ccb5370532f92cb9217e347ba69e96d24bc87;896b09b07b794ecb02d9b3be350b3166a22136fa920432c99dc7a73904c3dc50;36f1af1f7ef32a312af3bc7c3c010355bdda2156bd0baf0cc807b67a88b761a6;1b494029b063afa32918ce4ba8ec820e134946bd781458cdd55a41dc43af8a7c;41a8a503a8cef8c1df102599de83f6c2a3cf86c23cb2fbc8eedb18a6e52670d8".split(";")
if len(inputs) != len(expected_hashes) + 1:
    reject("invalid configured input inventory")
for index, path in enumerate(inputs):
    try:
        info = path.lstat()
    except OSError as error:
        reject(f"missing or unreadable required input '{path}': {error}; build hammond_standalone for the selected configuration before installing.")
    if not stat.S_ISREG(info.st_mode):
        reject(f"requires a regular input without symlinks: '{path}'")
    if info.st_size == 0:
        reject(f"required input is empty: '{path}'")
    digest = hashlib.sha256()
    try:
        with path.open("rb") as stream:
            while chunk := stream.read(1024 * 1024):
                digest.update(chunk)
    except OSError as error:
        reject(f"missing or unreadable required input '{path}': {error}")
    if index and digest.hexdigest() != expected_hashes[index - 1]:
        reject(f"configured notice/identity mismatch: '{path}'; reconfigure after an intentional input change.")
binary, metadata = [Path(value) for value in sys.argv[-2:]]
if binary == metadata or binary in metadata.parents:
    reject("executable and metadata destination paths conflict")
for destination in (binary, metadata):
    if os.path.lexists(destination):
        reject(f"destination already exists: '{destination}'; choose a fresh application destination; existing files/directories are never merged or replaced.")
    for parent in destination.parents:
        if os.path.lexists(parent) and not stat.S_ISDIR(parent.lstat().st_mode):
            reject(f"destination parent must be an ordinary directory without symlinks: '{parent}'")
]==] ${_hammond_standalone_inputs}
            "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/hammond_standalone"
            "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone"
            RESULT_VARIABLE _hammond_standalone_result
            OUTPUT_VARIABLE _hammond_standalone_output
            ERROR_VARIABLE _hammond_standalone_error)
        if(NOT "${_hammond_standalone_result}" STREQUAL "0")
            message(FATAL_ERROR "${_hammond_standalone_error}${_hammond_standalone_output}")
        endif()
    
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE PROGRAM FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/apps/standalone/hammond_standalone")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "STANDALONE_INSTALL.md" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/STANDALONE_INSTALL.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "STANDALONE_APP.md" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/STANDALONE_APP.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "STANDALONE_MODEL.md" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/STANDALONE_MODEL.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "MIDI_UI_RUNBOOK.md" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/MIDI_UI_RUNBOOK.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "PRESET_RUNBOOK.md" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/PRESET_RUNBOOK.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "INTERFACE_RUNBOOK.md" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/INTERFACE_RUNBOOK.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "THIRD_PARTY_NOTICES.md" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/THIRD_PARTY_NOTICES.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "LICENSE-SDL2.txt" FILES "/workspace/scratch/ade21b726509/SDL2/LICENSE.txt")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "LICENSE-DejaVu.txt" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/assets/standalone/fonts/LICENSE-DejaVu.txt")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "sdl2-lock.json" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/data/dependencies/sdl2-lock.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "font-source-manifest.json" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/assets/standalone/fonts/source-manifest.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "reference-source-manifest.json" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/assets/standalone/reference/manifest.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "atlas-reference.json" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/design/atlas-reference.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "standalone-capabilities.json" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/build/generated/standalone-capabilities.json")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "MIDI_EXPRESSION_GUIDE.md" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/docs/MIDI_EXPRESSION_GUIDE.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Standalone")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/hammond-b3-organ/standalone" TYPE FILE RENAME "reference-apron-manifest.json" FILES "/workspace/scratch/3edffb787db3/a44-installed-flow/source/assets/standalone/reference-apron-v1/manifest.json")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/workspace/scratch/3edffb787db3/a44-installed-flow/build/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
if(CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_COMPONENT MATCHES "^[a-zA-Z0-9_.+-]+$")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
  else()
    string(MD5 CMAKE_INST_COMP_HASH "${CMAKE_INSTALL_COMPONENT}")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INST_COMP_HASH}.txt")
    unset(CMAKE_INST_COMP_HASH)
  endif()
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/workspace/scratch/3edffb787db3/a44-installed-flow/build/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
