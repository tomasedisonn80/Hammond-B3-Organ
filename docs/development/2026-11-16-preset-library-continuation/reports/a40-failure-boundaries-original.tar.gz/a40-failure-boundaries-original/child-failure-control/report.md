# Proposed starter registration auditions

Status: **failed**. 0 of 32 renders succeeded.

These are proposed, unmeasured recipes for the nominal dry Engine. They are not specimen measurements, factory recipes, or live-app evidence.

Each WAV is stereo PCM16, 48 kHz, exactly one second, with nominal contacts, seed 73, block size 64 and fail-on-clip. No normalization is applied.

Both suffixes use `--controls`: full state **including saved expression**. This does not perform Registration's expression-preserving library recall. Matching suffix pairs must produce identical complete WAV bytes.

## Listening order

`audition` is note-only: Upper C4/G4 at frames 0/9000, Lower C3 at 16000, pedal ID 1 at 26000, then Upper E4 + Lower G3 + pedal ID 8 at 36000. Manual notes use MIDI numbers; pedals use one-based IDs. Recipe 10's manual passages are silent; its pedals sound. Recipe 12's Upper remains cancelled.

`banks-reveal` (09–11) starts with the saved routes/fixed modes, selects both A banks at 12000, then both B banks at 24000. Selection reconnects routes and clears fixed modes. Recipe 11 initially sounds its saved D#/F modes.

`manual-return` (12) holds Upper C silently, reselects retained G# at 8000, selects both A banks at 18000, then both B banks at 30000. The later Upper-B attack makes saved percussion eligible. These explicitly named companion scores change selections; the initial-state provenance remains unchanged.

## Results

| Render | Result | WAV |
| --- | --- | --- |
| 01-audition-registration | failed | [01-audition-registration.wav](01-audition-registration.wav) |
| 01-audition-performance | not-run | — |
| 02-audition-registration | not-run | — |
| 02-audition-performance | not-run | — |
| 03-audition-registration | not-run | — |
| 03-audition-performance | not-run | — |
| 04-audition-registration | not-run | — |
| 04-audition-performance | not-run | — |
| 05-audition-registration | not-run | — |
| 05-audition-performance | not-run | — |
| 06-audition-registration | not-run | — |
| 06-audition-performance | not-run | — |
| 07-audition-registration | not-run | — |
| 07-audition-performance | not-run | — |
| 08-audition-registration | not-run | — |
| 08-audition-performance | not-run | — |
| 09-audition-registration | not-run | — |
| 09-audition-performance | not-run | — |
| 09-banks-reveal-registration | not-run | — |
| 09-banks-reveal-performance | not-run | — |
| 10-audition-registration | not-run | — |
| 10-audition-performance | not-run | — |
| 10-banks-reveal-registration | not-run | — |
| 10-banks-reveal-performance | not-run | — |
| 11-audition-registration | not-run | — |
| 11-audition-performance | not-run | — |
| 11-banks-reveal-registration | not-run | — |
| 11-banks-reveal-performance | not-run | — |
| 12-audition-registration | not-run | — |
| 12-audition-performance | not-run | — |
| 12-manual-return-registration | not-run | — |
| 12-manual-return-performance | not-run | — |

`manifest.json` records exact argv, actual executable/profile/payload/score SHA-256, raw stdout JSON/stderr and WAV identities, input recheck, and each attempt's status. A failed JSON capture may contain incomplete/non-JSON bytes; `stdout_is_json` states what was observed. Hashes identify files, not physical fidelity.

The batch stops on its first failure and retains actual partial outputs. There is no overwrite, rollback, automatic retry, or resume; choose another fresh output directory for a new run.

Failure: 01-audition-registration: renderer exited 3
