from contextlib import redirect_stdout, redirect_stderr
import errno
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
from unittest import mock

root = Path.cwd()
base = root / "out/a40-failure-boundaries-original"
reports = root / "docs/development/2026-11-16-preset-library-continuation/reports"
spec = importlib.util.spec_from_file_location("a40_auditions", root / "tools/audition_starter_registrations.py")
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
source_paths = [root / "tools/audition_starter_registrations.py", root / "tests/test_starter_auditions.py",
                root.parent / "build-native/hammond_render", root.parent / "build-native/nominal.b3p",
                root / "data/registrations/starter-v1/recipes.json"]
source_paths += sorted((root / "data/registrations/starter-v1/entries").iterdir())
source_paths += sorted((root / "examples/registrations").glob("starter-*.events"))
def record(path):
    raw = path.read_bytes()
    return {"path": str(path), "size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
original_inputs = [record(path) for path in source_paths]
raw_write = a._write_new
cases = []
for failed_report in (None, "manifest.json", "report.md"):
    output = base / (failed_report or "child-failure-control")
    count = 0
    def child(argv, **kwargs):
        global count
        count += 1
        Path(argv[argv.index("--output") + 1]).write_bytes(b"RIFFpartial")
        kwargs["stdout"].write(b'{"a40_injected_failure":true}\n')
        kwargs["stderr"].write(b"A40 controlled child exit 3; no native renderer ran\n")
        return subprocess.CompletedProcess(argv, 3)
    def write(path, raw):
        if path.name == failed_report:
            with path.open("xb") as stream:
                stream.write(raw[:19])
            raise OSError(errno.ENOSPC, "A40 controlled late aggregate write failure")
        raw_write(path, raw)
    stdout, stderr = io.StringIO(), io.StringIO()
    argv = ["--renderer", str(root.parent / "build-native/hammond_render"),
            "--profile", str(root.parent / "build-native/nominal.b3p"),
            "--pack", str(root / "data/registrations/starter-v1"), "--output", str(output)]
    with mock.patch.object(a.subprocess, "run", side_effect=child), mock.patch.object(a, "_write_new", side_effect=write), redirect_stdout(stdout), redirect_stderr(stderr):
        code = a.main(argv)
    assert code == 1 and count == 1
    (base / f"{output.name}.stdout.txt").write_text(stdout.getvalue(), encoding="utf-8")
    (base / f"{output.name}.stderr.txt").write_text(stderr.getvalue(), encoding="utf-8")
    files = [record(path) for path in sorted(output.rglob("*")) if path.is_file()]
    entry = {"failed_report": failed_report, "argv": argv, "returncode": code, "injected_child_calls": count,
             "stdout": stdout.getvalue(), "stderr": stderr.getvalue(), "retained_files": files}
    if failed_report != "manifest.json":
        manifest = json.loads((output / "manifest.json").read_bytes())
        entry["manifest_status"] = manifest["status"]
        entry["attempted_jobs"] = manifest["attempted_jobs"]
        entry["completed_jobs"] = manifest["completed_jobs"]
        assert (manifest["status"], manifest["attempted_jobs"], manifest["completed_jobs"]) == ("failed", 1, 0)
    if failed_report is None:
        entry["report_overclaims_all_wav_completeness"] = "Each WAV is stereo PCM16, 48 kHz, exactly one second" in (output / "report.md").read_text()
        assert entry["report_overclaims_all_wav_completeness"]
    else:
        assert "audition refused:" in stderr.getvalue() and stdout.getvalue() == ""
    cases.append(entry)
assert [record(path) for path in source_paths] == original_inputs
archive = reports / "a40-failure-boundaries-original.tar.gz"
with tarfile.open(archive, "x:gz") as tar:
    tar.add(base, arcname=base.name)
receipt = {"schema_version": 1, "worker": "A40", "evidence_kind": "deterministic_injected_io_failures_no_native_render",
           "cwd": str(root), "head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
           "python": sys.version, "platform": sys.platform,
           "command": "python3 -B out/a40-failure-boundaries-original/probe.py",
           "inputs": original_inputs, "inputs_unchanged": True, "cases": cases, "archive": record(archive),
           "limits": ["No native render, build, configure, full suite, physical or platform claim.",
                      "ENOSPC and child exit are injected; this does not claim observed storage exhaustion.",
                      "Each case attempts one synthetic child and preserves all actual files including failed report prefixes."]}
path = reports / "a40-failure-boundaries-original.json"
with path.open("x", encoding="utf-8") as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"receipt": record(path), "archive": record(archive), "cases": [{k:v for k,v in c.items() if k in ("failed_report", "returncode", "injected_child_calls", "stdout", "stderr", "report_overclaims_all_wav_completeness")} for c in cases]}, indent=2))
