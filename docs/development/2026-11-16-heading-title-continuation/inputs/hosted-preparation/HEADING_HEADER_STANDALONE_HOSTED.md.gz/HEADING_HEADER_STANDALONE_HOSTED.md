# Heading, title and header standalone hosted verification

## Current status

**Prepared; awaiting root's exact published source SHA.** A53 has not queried
uncreated runs, rerun a workflow or changed any remote state. The separately
published pre-H1 revision `9d60dbf462a90fe422fd4e69757fe202264acb7c` and old
T2 hosted results do not qualify the combined source. Actual job conclusions,
native test counts, sanitizer execution and package outcomes remain pending.

The [A53 receipt](../development/2026-11-16-heading-title-continuation/reports/a53-standalone-hosted.json)
records the complete required-name/mapping inventory, inspected source
identities, and an independent
[combined-workspace failure diagnosis](COMBINED_WORKSPACE_REPLAY_DIAGNOSIS.md).
The latter retains an observed failure and is separate from hosted acceptance.
Root owns publication, workflow/source edits, native execution and any retry.

## Frozen workflow inventory

The inspected `.github/workflows/standalone.yml` is 70,886 bytes with SHA-256
`b572d1e34d891657964d8ca6f5882fbaf157ab91ddbb309fd183af89fbdfac6e`.
It agrees with the [A51 source audit](HEADING_HEADER_FINAL_SOURCE_AUDIT.md).
Any changed published workflow must be explicitly rebound before verification.

| Job family | Runner label | MIDI backend | Required outcome |
| --- | --- | --- | --- |
| Linux GCC, MIDI ON | `ubuntu-24.04` | ALSA | All standalone tests and exact relocated package |
| macOS AppleClang, MIDI ON | `macos-15` | CoreMIDI | All standalone tests and exact relocated package |
| macOS Intel AppleClang, MIDI ON | `macos-15-intel` | CoreMIDI | All standalone tests and exact relocated package |
| Windows MSVC x64, MIDI ON | `windows-2022` | WinMM | All standalone tests and exact relocated package |
| Linux GCC, MIDI OFF | `ubuntu-24.04` | Unavailable | All standalone tests and exact relocated package |
| Linux GCC ASan + UBSan + leaks | `ubuntu-24.04` | Unavailable; separate fake probe | All 33 selected instrumented gates |

Runner labels are the workflow's requests. Actual run/job IDs, attempt,
runner identity and architecture must come from the released revision's
executed job metadata and provenance. The workflow checks out the exact
GitHub SHA, records source/tree/dependencies and verifies tracked-source
cleanliness. Its cancellation policy means a later push can cancel earlier
work; an incomplete or cancelled job cannot be reported as a pass.

## Normal native and package gates

Each of the five normal jobs discovers every `^test_standalone_` test,
requires 44 explicit names to exist and be enabled with built inputs, and
runs the entire prefix serially. Forty-four is the minimum required set,
not a prediction of actual platform discovery. The newly required statistics,
grain-bounds and real-application paint-boundary gates must appear in the
actual results alongside title density, starter Load, MIDI, calibration,
workspace and the retained raster gates.

The workflow verifies the actual compiler, compiled native SDL backends,
locked SDL2 and RtMidi identities, support-library MIDI definition and backend
API. MIDI OFF must neither acquire nor build RtMidi. It builds the aggregate
acceptance inputs and reverifies source and dependencies after tests.

Each successful normal job installs the Standalone component, checks the
exact 21-file MIDI-enabled or 17-file MIDI-disabled inventory, hashes/modes,
and absence of symlink/reparse surprises, then moves the install prefix. From
outside the repository it exercises relocated help and the fixed 600 ms
default-size dummy smoke. The resulting MIDI state must be closed or
unavailable and quiescent. Installed bytes remain unchanged. Archive members,
bytes and modes must reproduce that same payload. Package upload is gated on
success; diagnostic retention alone does not establish package success.

## Exact sanitizer expansion

The sanitizer inventory contains 33 CTests mapped to 31 build targets. The
receipt retains every exact mapping. Title density shares its footage native
fixture; statistics shares the header-material fixture; paint boundary uses
the real standalone executable; calibration uses the fake-backend probe.

| Newly included gate | Actual input | Required discovery/timeout |
| --- | --- | --- |
| Header statistics | Instrumented header-material fixture | Seven-argument Python command; 60 s child; 240 s CTest |
| Header grain bounds | Dedicated native grain fixture | One native command; 90 s CTest |
| Replay paint boundary | Instrumented real standalone app | Seven-argument Python command; 30 s child; 90 s CTest |

Project C++ and SDL C objects must carry address/undefined sanitizer flags
and frame pointers. Object/archive symbol evidence and linked ASan/UBSan
runtimes are required. The real application compiles main and painter; the
grain fixture includes the real painter exactly once. The workflow correctly
checks the private MIDI-disabled definition on `hammond_standalone_support`,
while the calibration probe retains its MIDI-enabled fake-header substitution.
Both entry paths must link the six instrumented archives. Requiring the
private definition on the application instead would be incorrect; that
pre-execution draft was withdrawn in A51's audit.

Policy remains strict: `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1`,
`UBSAN_OPTIONS=print_stacktrace=1:halt_on_error=1`, and
`LSAN_OPTIONS=exitcode=23`. Discovery must contain exactly the selected
33 enabled gates, matching target paths and permitted commands/timeouts, with
no test-level sanitizer override. Execution is serial. The post-test native
calibration receipt must account for ten actual subprocesses, seven lifecycle
scenarios and two deliberate replay failures using the same instrumented
probe, with no sanitizer text in child stderr.

## Verification procedure and limits

After root releases the exact source SHA, A53 will bind the workflow run and
every job/attempt to it, inspect terminal conclusions and bounded relevant
logs, and retain exact discovery, native-suite, instrumentation, calibration
and package summaries. A failed job's original relevant failure block will
be hashed and retained immediately without retry. Successful upload steps
will be distinguished from independently downloaded artifact-byte inspection.

No hosted result is claimed yet. Dummy MIDI, SDL software/dummy execution and
the fake test probe do not establish physical-device behavior, real-display
presentation, native accessibility or literal whole-interface reference
parity. Those exits remain open regardless of CI status.
