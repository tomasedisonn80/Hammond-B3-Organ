# Heading and header Core CI observation

**Preparation is complete; no exact new published source has been released for
A52 to observe. Hosted Core CI qualification is pending.** A52, wave 9,
17 November 2026 UTC. Root owns publication, any retry decision and the final
aggregate. A52 has made zero remote API requests and executed zero native
processes at this preparation stage.

The [preparation inventory](../development/2026-11-16-heading-title-continuation/reports/a52-core-hosted/preparation.json)
records the inspected workflow hash, all required jobs, explicit registration
and apron gates, policies and observation procedure. The
[current report](../development/2026-11-16-heading-title-continuation/reports/a52-core-hosted.json)
will bind any subsequent exact-source observations. The current concurrent
remote `9d60dbf462a90fe422fd4e69757fe202264acb7c` and older T2 successes are
different sources; neither is admitted as qualification of the combined work.

## Required job inventory

| Job | Requested runner | Required outcome |
| --- | --- | --- |
| Release (Linux GCC) | ubuntu-24.04 | Actual configure/build, unfiltered nonempty CTest and Linux supplemental gates |
| Release (macOS AppleClang) | macos-15 | Actual runner architecture, configure/build and unfiltered nonempty CTest |
| Release (macOS Intel AppleClang) | macos-15-intel | Actual runner architecture, configure/build and unfiltered nonempty CTest |
| Release (Windows MSVC) | windows-2022 | Configure/build, unfiltered CTest and actual Unicode-checkout canonical generator |
| Complete R4 waveform qualification (Linux GCC) | ubuntu-24.04 | Report-admission self-test and actual complete waveform target |
| Linux GCC ASan + UBSan + leaks | ubuntu-24.04 | Instrumented configure/build and actual unfiltered nonempty CTest with policy intact |

Release jobs request CTest parallelism two, timeout 300 and `--no-tests=error`.
The sanitizer job requests parallelism two, timeout 600 and the same nonempty
guard. Required sanitizer policy is `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1`,
`UBSAN_OPTIONS=print_stacktrace=1:halt_on_error=1` and `LSAN_OPTIONS=exitcode=23`.
The exact observed test count must come from the new source's logs; a historical
count is not an expected-result substitute. The twelve explicit registration
and apron names are retained in the inventory rather than inferred from a job
title. Three embedded Python blocks parsed during preparation.

## Observation and preservation boundary

After root supplies the exact published SHA, independently fetch its commit and
tree, then only matching-head Core CI runs and jobs. Bind every run and attempt,
runner assignment, status, conclusion and decisive test summary to that SHA.
Use the connected GitHub read-only fetch and job-log APIs. Keep first attempts,
failures and cancellations even if root subsequently authorizes another attempt.
The workflow cancels older concurrent runs; a cancellation with no assigned
runner does not establish compilation or testing. Matrix fail-fast is disabled.

Retain necessary bounded original logs with byte counts and SHA-256; report
compact metadata and decisive lines. Do not dump raw logs, base64 archives or
account metadata into conversation. A runner label alone does not establish
macOS architecture. A green job summary without actual test evidence does not
establish how many gates ran. R4 numerical qualification does not establish
physical Hammond equivalence, native hardware behavior or full-interface visual
equivalence. Root independently refetches material source evidence before final
publication claims.

## Additional local diagnosis

While publication waits, root assigned A52 the completed combined-suite MIDI
failure. Its [separate review](COMBINED_MIDI_REPLAY_DIAGNOSIS.md) preserves the
original result, actual late acknowledged observation, successful completion,
unreached tail assertions and limits of scheduling inference. This is a local
diagnosis role addition, not a seventh Core CI job or hosted qualification.

Next step: root's unchanged isolated comparison and subsequent exact-source
publication. No new run is polled before publication; no source, test-oracle,
workflow, remote-ref, rerun or external-comment mutation is authorized to A52.
